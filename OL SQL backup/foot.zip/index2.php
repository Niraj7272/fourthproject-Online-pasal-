 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>fade effect image slider</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <div>
    <?php
    include 'header.php';
    ?>
     <img src="img/main/image1.jpeg" class="slide-1">
    <img src="img/main/image3.jpeg" class="slide-2">
    <img src="img/main/image4.jpeg" class="slide-3">
    <img src="img/main/image5.jpeg" class="slide-4">
    </div>
    <?php
      include 'footer.php';
    ?>
</body>
</html>

