<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>addcatrgory Page</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<div class="sidebar">
        <div class="logo"></div>
        <ul class="menu">
           <li class="active">
            <a href="#">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
           </li>
           <li>
            <a href="#">
                <i class="fas fa-user"></i>
                <span>Profile</span>
            </a>
           </li>
           <li>
            <a href="#">
            <i class="fa-solid fa-gift"></i>
                <span>Products</span>
            </a>
           </li>
           <li>
            <a href="userstable.php">
            <i class="fa-solid fa-user-plus"></i>
                <span>Users</span>
            </a>
           </li>
           <li>
            <a href="#">
            <i class="fa-solid fa-truck"></i>
                <span>Orders</span>
            </a>
           </li>
           <li>
            <a href="#">
            <i class="fa-sharp fa-solid fa-cart-plus"></i>
                <span>Category</span>
            </a>
           </li>
           <li class="logout">
            <a href="#">
            <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>
           </li>
        </ul>
    </div>
</div>
</body>
</html>