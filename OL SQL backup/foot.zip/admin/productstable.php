<?php
include '../config.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>addusers Page</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<div class="sidebar">
        <div class="logo"></div>
        <ul class="menu">
           <li>
            <a href="dashboard.php">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
           </li>
           <li>
            <a href="#">
                <i class="fas fa-user"></i>
                <span>Profile</span>
            </a>
           </li>
           <li class="active">
            <a href="productstable.php">
            <i class="fa-solid fa-gift"></i>
                <span>Products</span>
            </a>
           </li>
           <li>
            <a href="userstable.php">
            <i class="fa-solid fa-user-plus"></i>
                <span>Users</span>
            </a>
           </li>
           <li>
            <a href="#">
            <i class="fa-solid fa-truck"></i>
                <span>Orders</span>
            </a>
           </li>
           <li>
            <a href="#">
            <i class="fa-sharp fa-solid fa-cart-plus"></i>
                <span>Category</span>
            </a>
           </li>
           <li class="logout">
            <?php
               if(isset($_SESSION['user_type'])){
             echo'<a href="../log_out.php" onclick="return confirm(\'You Are Sure You Want To Logout?\');">
            <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>';
               }
            ?>
           </li>
        </ul>
    </div>
<!-- main body section -->
    <div class="main-content">
        <div class="header-wrapper">
            <div class="header-title">
                <h2>Products</h2>
            </div>
            <div class="user-info">
                <a href="profile.php"><img src="./profile/pic1.jpg" alt=""></a>
                <!-- <a href="profile.php"><img src="./profile/blankimage.png" alt=""></a> -->
            <select>
            <option>profile</a></option>
                <option value="home">home</option>
                <option value="logout">Logout</option>
            </select>
            </div>
        </div>

        <div class="tabular-wrapper">
        <h3 class="main-title">Products List</h3>
        <div class="table-container">

        <?php
          $i = 1;
          $rows = mysqli_query($conn, "SELECT *FROM products");
          if(mysqli_num_rows($rows)>0){

           echo' <table>
                <thead>
                    <tr>
                        <th>SI No</th>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Stock</th>
                        <th>Product_Type</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>';
                ?>
                <?php foreach($rows as $row) : ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo $row["productId"]; ?></td>
            <td><?php echo $row["productName"]; ?></td>
            <td><?php echo $row["price"]; ?></td>
            <td><?php echo $row["description"]; ?></td>
            <td><?php echo $row["category"]; ?></td>
            <td><?php echo $row["stock"]; ?></td>
            <td><?php echo $row["productType"]; ?></td>
            <td><img src="../img/productimage/<?php echo $row['image']; ?>" width="100" height="100" title=""></td>
            <td>
                <a href="delete.php?delete=<?php echo $row['productId']?>" 
                class="delete_product_btn" onclick="return confirm('Are you sure you want to delete');">
                <i class="fas fa-trash"></i></a>

            </td>
        </tr>
          <?php 
          endforeach; 
        }
          else{
            echo"<div class='empty_text'>No Products Available</div>";
          }
          ?>
            </table>
        </div>
    </div>
</div>
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
</body>
</html>