<?php
session_start();
include 'config.php';
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main home page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="indexbody">
    <div class="header">
    <?php
      include 'header.php';
      include 'header2.php';
    ?>
    </div>
    <div id="main">
        <img class="indeximg" src="img/main/image1.jpeg" id="slideimage">
    </div>

    <script>
        function first(){
            document.getElementById("slideimage").src="img/main/image2.jpeg";
        }
        function second(){
            document.getElementById("slideimage").src="img/main/image3.jpeg";
        }
        function third(){
            document.getElementById("slideimage").src="img/main/image4.jpeg";
        }
        function fourth(){
            document.getElementById("slideimage").src="img/main/image1.jpeg";
        }
        setInterval(first,4000);
        setInterval(second,8000);
        setInterval(third,12000);
        setInterval(fourth,16000);
    
    </script>
    <?php
     include 'foot.php';
    ?>
</body>
</html>