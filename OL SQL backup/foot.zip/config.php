<?php

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'fourthproject';

//set connection variables
$conn = mysqli_connect($host, $user, $password, $db);

?>