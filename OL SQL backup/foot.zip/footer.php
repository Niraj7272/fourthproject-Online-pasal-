<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<div class="container">
    <footer class="text-center text-lg-start border border-white mt-xl-5 pt-4">
    <div class="container p-4">
      <div class="row">
        <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
          <h5 class="text-uppercase mb-4">Contact Us:</h5>

          <ul class="list-unstyled mb-4">
          <li>
              <a href="https://mail.google.com/mail/u/0/#inbox?compose=CllgCJNsLvWJZnMjHKrlxJhJvfTcGrFQsphlclvTjckRjXLrTxzXMxppXWLShMSvfVdFnzQnCKL" class="text-black">nepal4972@gmail.com</a>
            </li>
            <li>
              <a href="https://mail.google.com/mail/u/0/#inbox?compose=GTvVlcSBpDfsGzrtxlZdkHrWVPwnzCxWdxKbpltTTxlnpSvghJwxlCzzqPFvpXXHXRPWqKVVhmRhR" class="text-black">sandnnepal4972@gmail.com</a>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="text-center p-3 border-top border-white">
      2022 Copyright © HamroPC Project
    </div>
  </footer>
</div>
